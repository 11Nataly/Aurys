// src/Joven/pages/Promesas.jsx
import React from 'react';

const Promesas = () => {
  return (
    <div className="promesas-page">
      <h1>Promesas</h1>
      <p>Contenido de promesas aquí...</p>
    </div>
  );
};

export default Promesas;