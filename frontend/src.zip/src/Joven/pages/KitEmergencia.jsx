import EmergencyKit from "../components/KitEmergencia/EmergencyKit";

export default function KitEmergencia() {
  return (
    <div className="page-inner">
      <EmergencyKit />
    </div>
  );
}