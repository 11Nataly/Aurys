import React from "react";

export default function Perfil() {
  return (
    <div>
      <h1>Hola Usuario</h1>
    </div>
  );
}