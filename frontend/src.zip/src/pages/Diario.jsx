// src/pages/Diario.jsx
import { useState, useEffect } from 'react';
import DiarioHeader from '../components/Diario/DiarioHeader';
import EditorDiario from '../components/Diario/EditorDiario';
import HistorialEntradas from '../components/Diario/HistorialEntradas';
import AgregarEntrada from '../components/Diario/AgregarEntrada';
import '../styles/diario.css';

const Diario = () => {
  const [vistaActual, setVistaActual] = useState('agregar'); // Cambiado a 'agregar' por defecto
  const [entradas, setEntradas] = useState([]);
  const [entradaEditando, setEntradaEditando] = useState(null);

  // Efecto para persistir las entradas en localStorage
  useEffect(() => {
    const entradasGuardadas = localStorage.getItem('diarioEntradas');
    if (entradasGuardadas) {
      setEntradas(JSON.parse(entradasGuardadas));
      
      // Si hay entradas, mostrar el editor en lugar del formulario de agregar
      if (JSON.parse(entradasGuardadas).length > 0) {
        setVistaActual('editor');
      }
    }
  }, []);

  // Efecto para guardar las entradas en localStorage cuando cambien
  useEffect(() => {
    localStorage.setItem('diarioEntradas', JSON.stringify(entradas));
  }, [entradas]);

  const agregarEntrada = (nuevaEntrada) => {
    const id = Date.now();
    const fecha = new Date().toLocaleDateString('es-ES', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
    
    const entradaCompleta = { 
      id, 
      fecha, 
      ...nuevaEntrada 
    };
    
    setEntradas([...entradas, entradaCompleta]);
    setVistaActual('editor'); // Volver al editor después de agregar
  };

  const editarEntrada = (entradaEditada) => {
    setEntradas(entradas.map(entrada => 
      entrada.id === entradaEditada.id ? entradaEditada : entrada
    ));
    setVistaActual('editor'); // Volver al editor después de editar
    setEntradaEditando(null);
  };

  const eliminarEntrada = (id) => {
    setEntradas(entradas.filter(entrada => entrada.id !== id));
  };

  const renderVista = () => {
    switch (vistaActual) {
      case 'historial':
        return (
          <HistorialEntradas 
            entradas={entradas}
            onEditar={(entrada) => {
              setEntradaEditando(entrada);
              setVistaActual('agregar');
            }}
            onEliminar={eliminarEntrada}
            onVolver={() => setVistaActual('editor')}
          />
        );
      
      case 'agregar':
        return (
          <AgregarEntrada
            entrada={entradaEditando}
            onGuardar={entradaEditando ? editarEntrada : agregarEntrada}
            onCancelar={() => {
              setEntradaEditando(null);
              // Si no hay entradas, mantener en vista agregar
              // Si hay entradas, volver al editor
              setVistaActual(entradas.length === 0 ? 'agregar' : 'editor');
            }}
          />
        );
      
      default:
        return (
          <EditorDiario 
            entradas={entradas}
            onVerHistorial={() => setVistaActual('historial')}
            onAgregarEntrada={() => {
              setEntradaEditando(null);
              setVistaActual('agregar');
            }}
          />
        );
    }
  };

  return (
    <div className="diario-page">
      <div className="diario-container">
        <DiarioHeader 
          vistaActual={vistaActual}
          onCambiarVista={setVistaActual}
          tieneEntradas={entradas.length > 0}
        />
        {renderVista()}
      </div>
    </div>
  );
};

export default Diario;