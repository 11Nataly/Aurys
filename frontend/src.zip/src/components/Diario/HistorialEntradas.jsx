const HistorialEntradas = ({ entradas, onEditar, onEliminar, onVolver }) => {
  return (
    <div className="historial-entradas">
      <div className="historial-header">
        <h2>Historial de Entradas</h2>
        <button className="btn-volver" onClick={onVolver}>
          ← Volver
        </button>
      </div>
      
      {entradas.length === 0 ? (
        <p className="sin-entradas">No hay entradas previas</p>
      ) : (
        <div className="lista-entradas">
          {entradas.map(entrada => (
            <div key={entrada.id} className="entrada-historial">
              <div className="entrada-historial-header">
                <h3>{entrada.titulo}</h3>
                <span>{entrada.fecha}</span>
              </div>
              <div className="entrada-historial-acciones">
                <button onClick={() => onEditar(entrada)}>
                  ✏️
                </button>
                <button onClick={() => onEliminar(entrada.id)}>
                  🗑️
                </button>
              </div>
              <p className="entrada-historial-preview">
                {entrada.contenido.substring(0, 150)}...
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default HistorialEntradas;