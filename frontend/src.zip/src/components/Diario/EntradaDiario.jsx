//src/components/Diario/EntradaDiario.jsx
const EntradaDiario = ({ entrada, onEditar, onEliminar }) => {
  if (!entrada) {
    return (
      <div className="entrada-diario">
        <p>No hay entradas en el diario. ¡Crea una nueva!</p>
      </div>
    );
  }

  return (
    <div className="entrada-diario">
      <div className="entrada-acciones">
        <button className="btn-editar" onClick={onEditar}>
          <i className="fas fa-edit"></i>
        </button>
        <button className="btn-eliminar" onClick={onEliminar}>
          <i className="fas fa-trash"></i>
        </button>
      </div>
      <h2 className="entrada-titulo">{entrada.titulo}</h2>
      <p className="entrada-fecha">{entrada.fecha}</p>
      <div className="entrada-contenido">
        {entrada.contenido}
      </div>
    </div>
  );
};

export default EntradaDiario;