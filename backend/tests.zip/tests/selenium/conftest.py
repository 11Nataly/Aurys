import pytest
import os

# Configuración global para pruebas Selenium
@pytest.fixture(scope="session")
def base_url():
    """URL base para las pruebas"""
    return os.getenv("TEST_BASE_URL", "http://localhost:8000")

@pytest.fixture(scope="session")
def headless():
    """Ejecutar en modo headless (sin interfaz gráfica)"""
    return os.getenv("HEADLESS", "false").lower() == "true"