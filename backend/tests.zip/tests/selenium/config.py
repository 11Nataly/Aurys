# tests/selenium/config.py
import os

class BackendConfig:
    """Configuración específica para backend FastAPI"""
    
    # URL del backend FastAPI
    BASE_URL = os.getenv("BACKEND_URL", "http://127.0.0.1:8000")
    
    # Rutas comunes de FastAPI
    PATHS = {
        "docs": "/docs",
        "redoc": "/redoc", 
        "openapi": "/openapi.json",
        "health": "/health",
        "login": "/api/login",  # ⚠️ AJUSTA según tus rutas
        "register": "/api/register"
    }
    
    # Credenciales de prueba - ⚠️ IMPORTANTE: AJUSTA ESTOS VALORES
    TEST_CREDENTIALS = {
        "email": "admin@aurys.com",      # ⚠️ CAMBIA por usuario REAL
        "password": "Admin123!",         # ⚠️ CAMBIA por contraseña REAL
        "invalid_email": "error@test.com",
        "invalid_password": "WrongPass123!"
    }
    
    # Configuración del navegador
    HEADLESS = os.getenv("HEADLESS", "false").lower() == "true"
    BROWSER = os.getenv("BROWSER", "firefox")  # firefox o chrome
    
    # Timeouts
    IMPLICIT_WAIT = 10
    EXPLICIT_WAIT = 15
    PAGE_LOAD_TIME = 3
    
    # Directorios
    SCREENSHOTS_DIR = "tests/selenium/screenshots"
    REPORTS_DIR = "tests/reports"
    
    # Configuración de la API
    API_HEADERS = {
        "Content-Type": "application/json",
        "Accept": "application/json"
    }