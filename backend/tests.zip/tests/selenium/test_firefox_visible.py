import pytest
import sys
import os
import time
from selenium import webdriver
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.firefox import GeckoDriverManager

# Agregar el directorio raíz al path para importar módulos de la app
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class TestBackendVisibleFirefox:
    """Pruebas de integración con Firefox VISIBLE (con interfaz)"""
    
    @pytest.fixture(autouse=True)
    def setup(self):
        """Configuración inicial del driver de Firefox VISIBLE"""
        # Configuración automática del GeckoDriver
        service = Service(GeckoDriverManager().install())
        
        # Opciones de Firefox - MODO VISIBLE
        firefox_options = webdriver.FirefoxOptions()
        
        # REMOVER headless para ver el navegador
        # firefox_options.add_argument("--headless")  # ⛔ COMENTA ESTA LÍNEA
        
        # Configuraciones opcionales para mejor visualización
        firefox_options.add_argument("--width=1200")
        firefox_options.add_argument("--height=800")
        
        print("🚀 Iniciando Firefox en modo VISIBLE...")
        self.driver = webdriver.Firefox(service=service, options=firefox_options)
        
        # Maximizar ventana
        self.driver.maximize_window()
        
        self.driver.implicitly_wait(10)
        self.wait = WebDriverWait(self.driver, 15)
        
        # URL base de tu aplicación
        self.base_url = "http://localhost:8000"
        
        yield
        
        # Pausa antes de cerrar para que puedas ver el resultado
        print("⏳ Cerrando navegador en 3 segundos...")
        time.sleep(3)
        
        # Limpieza después de cada test
        self.driver.quit()

    def test_home_page_visible(self):
        """Verifica que la página principal carga correctamente - VISIBLE"""
        print("📄 Navegando a la página principal...")
        self.driver.get(f"{self.base_url}/")
        
        # Espera explícita para que puedas ver la carga
        time.sleep(2)
        
        print("✅ Página principal cargada - revisa la ventana de Firefox")
        
        # Toma screenshot
        self.driver.save_screenshot("tests/selenium/screenshots/visible_home_page.png")

    def test_api_docs_visible(self):
        """Prueba la documentación de la API - VISIBLE"""
        print("📚 Navegando a la documentación de la API...")
        self.driver.get(f"{self.base_url}/docs")
        
        # Espera a que cargue la documentación
        time.sleep(3)
        
        print("✅ Documentación de API cargada - revisa Swagger UI")
        
        # Interactúa con elementos para demostrar funcionalidad
        try:
            # Busca algún elemento específico de Swagger
            swagger_element = self.driver.find_element(By.CLASS_NAME, "swagger-ui")
            print("🎯 Swagger UI detectado correctamente")
        except:
            print("⚠️  No se pudo encontrar Swagger UI específico")
        
        # Toma screenshot
        self.driver.save_screenshot("tests/selenium/screenshots/visible_swagger.png")

    def test_navigation_flow_visible(self):
        """Prueba de flujo de navegación - VISIBLE"""
        print("🧭 Iniciando flujo de navegación...")
        
        # 1. Ir a la página principal
        self.driver.get(f"{self.base_url}/")
        time.sleep(1)
        print("📍 Paso 1: Página principal")
        
        # 2. Ir a documentación Swagger
        self.driver.get(f"{self.base_url}/docs")
        time.sleep(2)
        print("📍 Paso 2: Documentación Swagger")
        
        # 3. Ir a documentación ReDoc
        self.driver.get(f"{self.base_url}/redoc")
        time.sleep(2)
        print("📍 Paso 3: Documentación ReDoc")
        
        # 4. Volver a página principal
        self.driver.get(f"{self.base_url}/")
        time.sleep(1)
        print("📍 Paso 4: De vuelta a página principal")
        
        print("✅ Flujo de navegación completado")

    def test_interactive_elements(self):
        """Prueba elementos interactivos en la documentación - VISIBLE"""
        print("🖱️ Probando elementos interactivos...")
        
        # Navegar a Swagger UI
        self.driver.get(f"{self.base_url}/docs")
        time.sleep(3)
        
        try:
            # Intentar encontrar y hacer clic en algún endpoint para expandirlo
            endpoints = self.driver.find_elements(By.CLASS_NAME, "opblock-tag")
            
            if endpoints:
                # Hacer clic en el primer endpoint para expandirlo
                endpoints[0].click()
                time.sleep(1)
                print("✅ Endpoint expandido - puedes ver los detalles")
                
                # Tomar screenshot del endpoint expandido
                self.driver.save_screenshot("tests/selenium/screenshots/visible_expanded_endpoint.png")
            else:
                print("ℹ️  No se encontraron endpoints para expandir")
                
        except Exception as e:
            print(f"⚠️  No se pudieron interactuar con los endpoints: {e}")

if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])