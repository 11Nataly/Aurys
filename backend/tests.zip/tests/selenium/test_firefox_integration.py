import pytest
import sys
import os
import time
from selenium import webdriver
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.firefox import GeckoDriverManager

# Agregar el directorio raíz al path para importar módulos de la app
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class TestBackendWithFirefox:
    """Pruebas de integración con Firefox para el backend"""
    
    @pytest.fixture(autouse=True)
    def setup(self):
        """Configuración inicial del driver de Firefox"""
        # Configuración automática del GeckoDriver
        service = Service(GeckoDriverManager().install())
        
        # Opciones de Firefox
        firefox_options = webdriver.FirefoxOptions()
        firefox_options.add_argument("--headless")  # Ejecutar en modo sin interfaz (opcional)
        
        self.driver = webdriver.Firefox(service=service, options=firefox_options)
        self.driver.implicitly_wait(10)
        self.wait = WebDriverWait(self.driver, 15)
        
        # URL base de tu aplicación - prueba diferentes puertos comunes
        self.base_url = "http://localhost:8000"  # Puerto por defecto de FastAPI/Uvicorn
        
        yield
        
        # Limpieza después de cada test
        self.driver.quit()

    def test_home_page_loads(self):
        """Verifica que la página principal carga correctamente"""
        # Prueba diferentes endpoints posibles
        endpoints_to_try = [
            "/",
            "/docs",  # Documentación de FastAPI
            "/redoc", # Documentación alternativa
            "/api",   # Endpoint API
            "/health" # Endpoint de salud
        ]
        
        page_loaded = False
        
        for endpoint in endpoints_to_try:
            try:
                full_url = f"{self.base_url}{endpoint}"
                print(f"🔍 Probando: {full_url}")
                self.driver.get(full_url)
                
                # Espera a que la página cargue
                time.sleep(2)
                
                # Verifica diferentes indicadores de que la página cargó
                page_source = self.driver.page_source
                current_url = self.driver.current_url
                
                if page_source and "html" in page_source.lower():
                    print(f"✅ Página cargada correctamente en: {current_url}")
                    page_loaded = True
                    
                    # Toma screenshot
                    self.driver.save_screenshot(f"tests/selenium/screenshots/home_page_{endpoint.replace('/', '_')}.png")
                    
                    # Verifica el título si existe
                    title = self.driver.title
                    if title:
                        print(f"📄 Título de la página: {title}")
                    else:
                        print("ℹ️  La página no tiene título, pero cargó correctamente")
                    
                    break
                    
            except Exception as e:
                print(f"❌ Error cargando {endpoint}: {e}")
                continue
        
        assert page_loaded, "Ninguno de los endpoints comunes respondió correctamente"

    def test_api_endpoints_accessible(self):
        """Verifica que los endpoints principales de la API son accesibles"""
        # Primero prueba la documentación de FastAPI
        endpoints = [
            "/docs",    # Swagger UI
            "/redoc",   # ReDoc
            "/openapi.json" # Esquema OpenAPI
        ]
        
        for endpoint in endpoints:
            try:
                self.driver.get(f"{self.base_url}{endpoint}")
                time.sleep(2)
                
                # Verifica que la página respondió
                if self.driver.page_source:
                    print(f"✅ {endpoint} está accesible")
                    
                    # Toma screenshot
                    filename = f"tests/selenium/screenshots/api_{endpoint.replace('/', '_')}.png"
                    self.driver.save_screenshot(filename)
                    
                else:
                    print(f"⚠️  {endpoint} no devolvió contenido")
                    
            except Exception as e:
                print(f"❌ Error accediendo a {endpoint}: {e}")

    def test_static_files_served(self):
        """Verifica que los archivos estáticos se sirven correctamente"""
        # Basado en tu estructura de carpetas
        static_endpoints = [
            "/static/",
            "/static/motivaciones/"
        ]
        
        for endpoint in static_endpoints:
            try:
                self.driver.get(f"{self.base_url}{endpoint}")
                time.sleep(1)
                
                # Solo verifica que no hay error 500
                page_source = self.driver.page_source.lower()
                
                if "internal server error" not in page_source and "error" not in page_source:
                    print(f"✅ {endpoint} respondió sin errores del servidor")
                else:
                    print(f"⚠️  {endpoint} podría tener problemas")
                    
            except Exception as e:
                print(f"❌ Error accediendo a {endpoint}: {e}")

    def test_backend_health_check(self):
        """Prueba específica para verificar el estado del backend"""
        # Intenta acceder a endpoints comunes de health check
        health_endpoints = [
            "/health",
            "/api/health", 
            "/status",
            "/api/status"
        ]
        
        healthy = False
        
        for endpoint in health_endpoints:
            try:
                self.driver.get(f"{self.base_url}{endpoint}")
                time.sleep(1)
                
                # Verifica la respuesta
                page_source = self.driver.page_source
                if page_source and len(page_source) > 0:
                    print(f"✅ Health check en {endpoint}: OK")
                    healthy = True
                    break
                    
            except Exception as e:
                print(f"❌ Health check falló en {endpoint}: {e}")
                continue
        
        # Esta prueba es informativa, no hace fail si no hay health check
        if not healthy:
            print("ℹ️  No se encontraron endpoints de health check")

if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])