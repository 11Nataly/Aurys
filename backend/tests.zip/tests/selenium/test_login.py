# tests/selenium/test_login.py
import pytest
import sys
import os
import time
import json
import requests
from selenium import webdriver
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.firefox import GeckoDriverManager

# Agregar el directorio raíz al path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class TestBackendLogin:
    """Pruebas de login para backend FastAPI - Endpoint: POST /auth/login"""
    
    @pytest.fixture(autouse=True)
    def setup(self):
        """Configuración inicial"""
        service = Service(GeckoDriverManager().install())
        
        # Firefox VISIBLE (comenta para headless)
        firefox_options = webdriver.FirefoxOptions()
        # firefox_options.add_argument("--headless")  # ⛔ COMENTA para ver el navegador
        
        print("🚀 Iniciando Firefox para probar backend FastAPI...")
        self.driver = webdriver.Firefox(service=service, options=firefox_options)
        self.driver.maximize_window()
        self.driver.implicitly_wait(10)
        self.wait = WebDriverWait(self.driver, 15)
        
        # URL base del BACKEND FastAPI
        self.base_url = "http://127.0.0.1:8000"
        
        # Endpoint de login CORRECTO
        self.login_endpoint = f"{self.base_url}/auth/login"
        
        # Credenciales de prueba - ⚠️ AJUSTA ESTOS VALORES CON USUARIOS REALES
        self.test_credentials = {
            "valid": {
                "email": "admin@aurys.com",      # ⚠️ CAMBIA por usuario REAL
                "password": "Admin123!"          # ⚠️ CAMBIA por contraseña REAL
            },
            "invalid": {
                "email": "error@test.com",
                "password": "WrongPass123!"
            },
            "empty": {
                "email": "",
                "password": ""
            }
        }
        
        yield
        
        # Pausa para ver resultados
        print("⏳ Cerrando navegador en 3 segundos...")
        time.sleep(3)
        self.driver.quit()
    
    def test_backend_is_running(self):
        """Verifica que el backend FastAPI está corriendo"""
        print("🔍 Verificando estado del backend FastAPI...")
        
        self.driver.get(self.base_url)
        time.sleep(2)
        
        current_url = self.driver.current_url
        print(f"📍 URL actual: {current_url}")
        
        # Verificar respuesta del backend
        page_source = self.driver.page_source.lower()
        
        if "fastapi" in page_source or "swagger" in page_source:
            print("✅ Backend FastAPI detectado")
        
        # Toma screenshot
        self.driver.save_screenshot("tests/selenium/screenshots/backend_home.png")
        
        return True
    
    def test_api_login_endpoint_exists(self):
        """Verifica que el endpoint /auth/login existe"""
        print("🔌 Probando endpoint de login: POST /auth/login")
        
        # Probar con petición HTTP directa
        test_data = {
            "email": self.test_credentials["valid"]["email"],
            "password": self.test_credentials["valid"]["password"]
        }
        
        try:
            response = requests.post(
                self.login_endpoint,
                json=test_data,
                timeout=10
            )
            
            print(f"📊 Status Code: {response.status_code}")
            print(f"📦 Headers: {dict(response.headers)}")
            
            # Intentar parsear la respuesta
            try:
                response_json = response.json()
                print(f"📄 Response JSON: {json.dumps(response_json, indent=2)}")
            except:
                print(f"📄 Response Text: {response.text[:500]}")
            
            # Verificar posibles respuestas
            if response.status_code == 200:
                print("✅ Endpoint responde con 200 OK")
                if "token" in response.text.lower():
                    print("✅ Token detectado en respuesta - Login exitoso")
                elif "access_token" in response.text.lower():
                    print("✅ Access token detectado - Login exitoso")
            elif response.status_code == 401:
                print("❌ 401 Unauthorized - Credenciales inválidas")
            elif response.status_code == 422:
                print("❌ 422 Validation Error - Datos inválidos")
            elif response.status_code == 404:
                print("❌ 404 Not Found - Endpoint no existe")
            else:
                print(f"⚠️  Respuesta inesperada: {response.status_code}")
                
        except requests.ConnectionError:
            print("❌ No se pudo conectar al endpoint")
        except requests.Timeout:
            print("❌ Timeout - El servidor no responde")
        except Exception as e:
            print(f"❌ Error: {e}")
        
        return True
    
    def test_login_with_valid_credentials(self):
        """Prueba login con credenciales válidas"""
        print("🔐 Probando login con credenciales VÁLIDAS...")
        
        # Crear una página HTML para probar el endpoint
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Prueba de Login API</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 40px; }}
                .container {{ max-width: 600px; margin: 0 auto; }}
                .form-group {{ margin-bottom: 15px; }}
                label {{ display: block; margin-bottom: 5px; font-weight: bold; }}
                input {{ width: 100%; padding: 8px; box-sizing: border-box; }}
                button {{ background: #007bff; color: white; padding: 10px 20px; border: none; cursor: pointer; }}
                .result {{ margin-top: 20px; padding: 15px; background: #f8f9fa; border-radius: 5px; }}
                .success {{ color: green; }}
                .error {{ color: red; }}
            </style>
        </head>
        <body>
            <div class="container">
                <h2>Prueba de Login - POST /auth/login</h2>
                
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" value="{self.test_credentials['valid']['email']}">
                </div>
                
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" value="{self.test_credentials['valid']['password']}">
                </div>
                
                <button onclick="testLogin()">Probar Login</button>
                
                <div class="result" id="result">
                    <h3>Resultado:</h3>
                    <pre id="output">Presiona el botón para probar...</pre>
                </div>
                
                <div class="info">
                    <h4>Endpoint siendo probado:</h4>
                    <code>{self.login_endpoint}</code>
                </div>
            </div>
            
            <script>
                async function testLogin() {{
                    const email = document.getElementById('email').value;
                    const password = document.getElementById('password').value;
                    const output = document.getElementById('output');
                    
                    output.textContent = "Enviando petición...";
                    
                    try {{
                        const response = await fetch('{self.login_endpoint}', {{
                            method: 'POST',
                            headers: {{
                                'Content-Type': 'application/json',
                                'Accept': 'application/json'
                            }},
                            body: JSON.stringify({{
                                email: email,
                                password: password
                            }})
                        }});
                        
                        const result = await response.json();
                        
                        let outputText = `✅ Status: ${{response.status}} ${{response.statusText}}\\n`;
                        outputText += `📊 Headers:\\n${{JSON.stringify(Object.fromEntries([...response.headers]), null, 2)}}\\n`;
                        outputText += `📦 Response:\\n${{JSON.stringify(result, null, 2)}}`;
                        
                        output.textContent = outputText;
                        
                        // Resaltar éxito o error
                        if (response.ok) {{
                            output.style.color = 'green';
                        }} else {{
                            output.style.color = 'red';
                        }}
                        
                    }} catch (error) {{
                        output.textContent = `❌ Error: ${{error}}`;
                        output.style.color = 'red';
                    }}
                }}
                
                // Probar automáticamente después de 2 segundos
                setTimeout(testLogin, 2000);
            </script>
        </body>
        </html>
        """
        
        # Guardar HTML temporal
        temp_file = "temp_login_test.html"
        with open(temp_file, "w", encoding="utf-8") as f:
            f.write(html_content)
        
        # Abrir en navegador
        self.driver.get(f"file:///{os.path.abspath(temp_file)}")
        time.sleep(5)  # Dar tiempo para que se ejecute automáticamente
        
        # Tomar screenshot
        self.driver.save_screenshot("tests/selenium/screenshots/login_test_valid.png")
        
        # Limpiar
        os.remove(temp_file)
        
        print("✅ Prueba de login completada. Revisa el navegador para ver resultados.")
    
    def test_login_with_invalid_credentials(self):
        """Prueba login con credenciales inválidas"""
        print("❌ Probando login con credenciales INVÁLIDAS...")
        
        # Probar directamente con requests
        test_data = {
            "email": self.test_credentials["invalid"]["email"],
            "password": self.test_credentials["invalid"]["password"]
        }
        
        try:
            response = requests.post(
                self.login_endpoint,
                json=test_data,
                timeout=10
            )
            
            print(f"📊 Status Code esperado (401 o similar): {response.status_code}")
            
            if response.status_code == 401:
                print("✅ Correcto: 401 Unauthorized para credenciales inválidas")
            elif response.status_code == 400:
                print("✅ Correcto: 400 Bad Request")
            else:
                print(f"⚠️  Respuesta inesperada: {response.status_code}")
            
            # Mostrar respuesta
            try:
                response_json = response.json()
                print(f"📄 Response: {json.dumps(response_json, indent=2)}")
            except:
                print(f"📄 Response Text: {response.text}")
                
        except Exception as e:
            print(f"❌ Error: {e}")
    
    def test_login_validation(self):
        """Prueba validación del endpoint"""
        print("📝 Probando validaciones...")
        
        test_cases = [
            {
                "name": "Campos vacíos",
                "data": {"email": "", "password": ""},
                "expected_status": 422  # Unprocessable Entity
            },
            {
                "name": "Email inválido",
                "data": {"email": "email-invalido", "password": "test123"},
                "expected_status": 422
            },
            {
                "name": "Falta email",
                "data": {"password": "test123"},
                "expected_status": 422
            },
            {
                "name": "Falta password",
                "data": {"email": "test@test.com"},
                "expected_status": 422
            }
        ]
        
        for test_case in test_cases:
            print(f"\n🧪 {test_case['name']}...")
            
            try:
                response = requests.post(
                    self.login_endpoint,
                    json=test_case["data"],
                    timeout=10
                )
                
                print(f"   Status: {response.status_code} (esperado: {test_case['expected_status']})")
                
                if response.status_code == test_case["expected_status"]:
                    print("   ✅ Validación funcionando correctamente")
                else:
                    print("   ⚠️  Validación diferente a la esperada")
                    
            except Exception as e:
                print(f"   ❌ Error: {e}")
    
    def test_swagger_documentation(self):
        """Verifica que el endpoint esté documentado en Swagger"""
        print("📚 Verificando documentación en Swagger...")
        
        self.driver.get(f"{self.base_url}/docs")
        time.sleep(3)
        
        # Buscar endpoint /auth/login en la documentación
        page_source = self.driver.page_source
        
        if "/auth/login" in page_source:
            print("✅ Endpoint /auth/login documentado en Swagger")
            
            # Buscar método POST
            if "POST" in page_source and "/auth/login" in page_source:
                print("✅ Método POST documentado para /auth/login")
            
            # Tomar screenshot del endpoint en docs
            self.driver.save_screenshot("tests/selenium/screenshots/swagger_auth_login.png")
        else:
            print("⚠️  Endpoint /auth/login no encontrado en Swagger")
            
        # Buscar en Redoc también
        self.driver.get(f"{self.base_url}/redoc")
        time.sleep(2)
        
        if "/auth/login" in self.driver.page_source:
            print("✅ Endpoint /auth/login documentado en ReDoc")
    
    def test_create_test_user_if_needed(self):
        """Sugiere crear usuario de prueba si no existe"""
        print("👤 Verificando usuario de prueba...")
        
        print(f"\n⚠️  IMPORTANTE: Asegúrate de tener este usuario en tu base de datos:")
        print(f"   Email: {self.test_credentials['valid']['email']}")
        print(f"   Password: {self.test_credentials['valid']['password']}")
        
        print("\n💡 Si no existe, puedes:")
        print("   1. Crearlo manualmente en la base de datos")
        print("   2. Usar el endpoint de registro si existe")
        print("   3. Modificar las credenciales en este archivo")
        
        # Verificar si el usuario existe probando login
        try:
            response = requests.post(
                self.login_endpoint,
                json=self.test_credentials["valid"],
                timeout=10
            )
            
            if response.status_code == 200:
                print(f"\n✅ Usuario de prueba VERIFICADO: Login exitoso")
            elif response.status_code == 401:
                print(f"\n❌ Usuario de prueba NO ENCONTRADO o credenciales incorrectas")
                print("   Status 401: Unauthorized")
            else:
                print(f"\n⚠️  Respuesta inesperada: {response.status_code}")
                
        except Exception as e:
            print(f"\n❌ Error verificando usuario: {e}")
    
    def test_explore_authentication_routes(self):
        """Explora otras rutas de autenticación"""
        print("🗺️ Explorando rutas de autenticación...")
        
        auth_routes = [
            "/auth/register",
            "/auth/logout",
            "/auth/refresh",
            "/auth/me",
            "/auth/verify",
            "/auth/reset-password",
            "/auth/forgot-password"
        ]
        
        for route in auth_routes:
            url = f"{self.base_url}{route}"
            print(f"\n🔍 Probando: {route}")
            
            # Intentar GET primero
            try:
                response = requests.get(url, timeout=5)
                print(f"   GET: {response.status_code}")
            except:
                print("   GET: Error o timeout")
            
            # Intentar POST con datos vacíos
            try:
                response = requests.post(url, json={}, timeout=5)
                print(f"   POST: {response.status_code}")
            except:
                print("   POST: Error o timeout")

if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s", "--tb=short"])