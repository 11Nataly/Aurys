#!/usr/bin/env python3
"""
Script para ejecutar pruebas Selenium con Firefox VISIBLE
"""

import subprocess
import sys
import os

def run_visible_tests():
    """Ejecuta las pruebas Selenium en modo visible"""
    
    print("🔧 Configurando pruebas Selenium con Firefox VISIBLE...")
    print("👀 ¡Se abrirá una ventana de Firefox para que veas las pruebas en vivo!")
    print("⏳ Las pruebas incluirán pausas para que puedas observar...")
    
    # Crear directorios necesarios
    os.makedirs("tests/reports", exist_ok=True)
    os.makedirs("tests/selenium/screenshots", exist_ok=True)
    
    # Comando para ejecutar pytest
    cmd = [
        sys.executable, "-m", "pytest",
        "tests/selenium/test_firefox_visible.py",
        "-v",
        "-s",  # Mostrar output de print statements
    ]
    
    try:
        print("🚀 Iniciando pruebas VISIBLES...")
        print("📝 Asegúrate de que tu servidor backend esté ejecutándose en http://localhost:8000")
        print("=" * 60)
        
        result = subprocess.run(cmd, check=False)
        
        print("=" * 60)
        if result.returncode == 0:
            print("✅ Todas las pruebas pasaron!")
        else:
            print(f"❌ Algunas pruebas fallaron (código: {result.returncode})")
            
        return result.returncode
        
    except Exception as e:
        print(f"💥 Error ejecutando pruebas: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(run_visible_tests())