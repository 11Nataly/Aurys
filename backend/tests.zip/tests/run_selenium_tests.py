#!/usr/bin/env python3
"""
Script para ejecutar pruebas Selenium con Firefox
"""

import subprocess
import sys
import os

def run_selenium_tests():
    """Ejecuta las pruebas Selenium"""
    
    print("🔧 Configurando pruebas Selenium con Firefox...")
    
    # Crear directorios necesarios
    os.makedirs("tests/reports", exist_ok=True)
    os.makedirs("tests/selenium/screenshots", exist_ok=True)
    
    # Comando para ejecutar pytest
    cmd = [
        sys.executable, "-m", "pytest",
        "tests/selenium/test_firefox_integration.py",
        "-v",
        "-s",  # Mostrar output de print statements
        "--html=tests/reports/selenium_report.html",
        "--self-contained-html"
    ]
    
    try:
        print("🚀 Iniciando pruebas...")
        print("📝 Nota: Asegúrate de que tu servidor backend esté ejecutándose en http://localhost:8000")
        print("=" * 60)
        
        result = subprocess.run(cmd, check=False)
        
        print("=" * 60)
        if result.returncode == 0:
            print("✅ Todas las pruebas pasaron!")
        else:
            print(f"❌ Algunas pruebas fallaron (código: {result.returncode})")
        
        print(f"📊 Reporte generado en: tests/reports/selenium_report.html")
        print(f"📸 Screenshots guardados en: tests/selenium/screenshots/")
            
        return result.returncode
        
    except Exception as e:
        print(f"💥 Error ejecutando pruebas: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(run_selenium_tests())