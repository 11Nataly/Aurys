#!/usr/bin/env python3
"""
Script para ejecutar pruebas de login del backend FastAPI
"""

import subprocess
import sys
import os
import time

def run_backend_login_tests():
    """Ejecuta pruebas de login del backend"""
    
    print("=" * 70)
    print("🔐 PRUEBAS DE LOGIN - ENDPOINT: POST /auth/login")
    print("=" * 70)
    
    # Verificar que estamos en el directorio correcto
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    
    print(f"📁 Directorio del proyecto: {project_root}")
    print(f"📂 Cambiando a directorio del proyecto...")
    
    original_dir = os.getcwd()
    os.chdir(project_root)
    
    # Verificar que el archivo de prueba existe
    test_file = "tests/selenium/test_login.py"
    if not os.path.exists(test_file):
        print(f"❌ Archivo no encontrado: {test_file}")
        os.chdir(original_dir)
        return 1
    
    print(f"✅ Archivo de pruebas encontrado: {test_file}")
    
    # Crear directorios necesarios
    os.makedirs("tests/selenium/screenshots", exist_ok=True)
    os.makedirs("tests/reports", exist_ok=True)
    
    print("\n📋 Preparando pruebas...")
    print("⚠️  IMPORTANTE: Asegúrate de que:")
    print("   1. El backend FastAPI esté ejecutándose en http://127.0.0.1:8000")
    print("   2. Tienes un usuario con estas credenciales:")
    print("      Email: admin@aurys.com ")
    print("      Password: Admin123!")
    print("   3. O MODIFICA las credenciales en test_login.py")
    print("-" * 50)
    
    respuesta = input("\n¿Continuar con las pruebas? (s/n): ")
    if respuesta.lower() != 's':
        print("❌ Pruebas canceladas")
        os.chdir(original_dir)
        return 0
    
    # Comando para ejecutar pytest
    timestamp = int(time.time())
    cmd = [
        sys.executable, "-m", "pytest",
        test_file,
        "-v",  # Verbose
        "-s",  # Mostrar output
        "--tb=short",  # Traceback corto
        f"--html=tests/reports/login_test_report_{timestamp}.html",
        "--self-contained-html",
        "--metadata", "Endpoint", "/auth/login"
    ]
    
    try:
        print(f"\n🚀 Ejecutando pruebas...")
        print(f"📝 Comando: {' '.join(cmd)}")
        print("-" * 50)
        
        result = subprocess.run(cmd, check=False)
        
        print("-" * 50)
        if result.returncode == 0:
            print("🎉 ¡TODAS LAS PRUEBAS PASARON!")
        else:
            print(f"⚠️  Algunas pruebas fallaron (código: {result.returncode})")
        
        # Mostrar resultados importantes
        report_path = f"tests/reports/login_test_report_{timestamp}.html"
        print(f"\n📊 Reporte generado: file:///{os.path.abspath(report_path)}")
        print(f"📸 Screenshots: tests/selenium/screenshots/")
        
        print("\n🔧 PUNTOS IMPORTANTES A VERIFICAR:")
        print("1. ¿El endpoint /auth/login responde?")
        print("2. ¿Las credenciales válidas devuelven token?")
        print("3. ¿Las credenciales inválidas devuelven 401?")
        print("4. ¿La validación funciona (campos vacíos, email inválido)?")
        
        # Volver al directorio original
        os.chdir(original_dir)
        
        return result.returncode
        
    except KeyboardInterrupt:
        print("\n\n⏹️  Pruebas interrumpidas por el usuario")
        os.chdir(original_dir)
        return 130
    except Exception as e:
        print(f"💥 Error ejecutando pruebas: {e}")
        os.chdir(original_dir)
        return 1

if __name__ == "__main__":
    sys.exit(run_backend_login_tests())